Universal Exterior Cleaning - Website

Files:
- index.html
- styles.css
- script.js
- /images (gallery images)

Quick preview:
Open index.html in your browser.

Free hosting (recommended):
Cloudflare Pages:
1) Create a GitHub repo and upload these files (keep /images folder).
2) In Cloudflare Pages: Create project -> connect GitHub -> pick repo -> deploy.
3) Add your domain in Cloudflare Pages -> follow DNS instructions.
